from django.apps import AppConfig


class SccAppConfig(AppConfig):
    name = 'SCC_app'
